#!/usr/bin/env python3
"""Hello World skill script for DCAF Skills demo."""
print("Hello, World from DCAF Skills! Chuck also says 'hi'")
print("This script was downloaded as a zip, extracted, and executed by the agent.")
